'use client';

import Link from 'next/link';
import { useAuth } from '@/context/AuthContext';
import { useSiteConfig } from '@/context/SiteConfigContext';

export default function QuickActions() {
  const { user } = useAuth();
  const { whatsappNumber } = useSiteConfig();

  // "Sell on Piitrade" leads to the store SUBSCRIPTION flow:
  // - Authenticated users → dashboard/store-rental to subscribe/manage their store plan
  // - Guests → login page with redirect back to the subscription page
  const sellHref = user
    ? '/dashboard/store-rental'
    : '/auth/login?next=/dashboard/store-rental';

  // Build WhatsApp href from admin-configured number, fallback to generic share
  const waHref = whatsappNumber
    ? `https://wa.me/${whatsappNumber.replace(/\D/g, '')}?text=Hi%20I%27d%20like%20to%20order%20from%20Piitrade`
    : 'https://wa.me/?text=Hi%20I%20found%20you%20on%20Piitrade';

  return (
    <section className="flex flex-wrap justify-center gap-2.5 py-4" aria-label="Quick actions">
      {/* WhatsApp keeps its brand-recognized green — the one intentional exception to the palette */}
      <a
        href={waHref}
        target="_blank"
        rel="noopener noreferrer"
        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-gradient-to-r from-green-500 to-emerald-600 text-white font-semibold text-sm hover:from-green-600 hover:to-emerald-700 hover:shadow-lg hover:-translate-y-0.5 transition-all shadow-sm interactive"
        aria-label="Start a WhatsApp conversation"
      >
        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
        </svg>
        WhatsApp Chat
      </a>

      <Link
        href="/listings?q=electronics"
        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-white border border-premium-navy/20 text-premium-navy font-semibold text-sm hover:bg-premium-navy hover:text-white hover:border-premium-navy hover:shadow-lg hover:-translate-y-0.5 transition-all shadow-sm interactive"
        aria-label="Browse tech sale"
      >
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
        </svg>
        Tech Sale
      </Link>

      {/* Sell on Piitrade — leads to store subscription plan, not registration */}
      <Link
        href={sellHref}
        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-gradient-to-r from-premium-navy to-[#6B2400] text-white font-semibold text-sm hover:shadow-lg hover:-translate-y-0.5 transition-all shadow-sm interactive"
        aria-label="Sell on Piitrade — subscribe to a Web Store plan"
      >
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
        </svg>
        Sell on Piitrade
      </Link>

      <Link
        href="/listings"
        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-gradient-to-r from-premium-gold to-premium-gold-dark text-white font-semibold text-sm hover:shadow-lg hover:-translate-y-0.5 transition-all shadow-sm interactive"
        aria-label="Browse all listings"
      >
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 10h16M4 14h16M4 18h16" />
        </svg>
        Browse All
      </Link>
    </section>
  );
}
