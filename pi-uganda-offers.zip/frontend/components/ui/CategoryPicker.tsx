'use client';

import { useState, useRef, useEffect } from 'react';
import { Category } from '@/lib/types';

interface CategoryPickerProps {
  categories: Category[];
  value: string;
  onChange: (id: string) => void;
  className?: string;
}

function findSelected(categories: Category[], id: string): string {
  for (const cat of categories) {
    if (cat.id === id) return cat.name;
    if (cat.children) {
      for (const sub of cat.children) {
        if (sub.id === id) return `${cat.name} › ${sub.name}`;
      }
    }
  }
  return '';
}

export default function CategoryPicker({ categories, value, onChange, className = '' }: CategoryPickerProps) {
  const [open, setOpen] = useState(false);
  const [activeParentId, setActiveParentId] = useState<string | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Close on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const selectedLabel = value ? findSelected(categories, value) : '';
  const activeParent = categories.find((c) => c.id === activeParentId) ?? categories.find((c) => c.children?.some((sub) => sub.id === value)) ?? null;

  const handleSelect = (id: string) => {
    onChange(id);
    setOpen(false);
    setActiveParentId(null);
  };

  const handleToggle = () => {
    setOpen((prev) => {
      const nextOpen = !prev;
      if (nextOpen) {
        const firstParentWithChildren = categories.find((cat) => cat.children?.length)?.id ?? null;
        setActiveParentId((current) => current ?? firstParentWithChildren);
      } else {
        setActiveParentId(null);
      }
      return nextOpen;
    });
  };

  return (
    <div ref={containerRef} className={`relative ${className}`}>
      {/* Trigger */}
      <button
        type="button"
        onClick={handleToggle}
        className="w-full flex items-center justify-between border border-gray-300 rounded-lg px-4 py-2.5 bg-white text-left focus:outline-none focus:ring-2 focus:ring-red-400 transition-colors hover:border-red-400"
        aria-expanded={open}
        aria-haspopup="dialog"
      >
        <span className={selectedLabel ? 'text-gray-900' : 'text-gray-400'}>
          {selectedLabel || 'Select a category'}
        </span>
        <svg
          className={`w-4 h-4 text-gray-400 transition-transform flex-shrink-0 ${open ? 'rotate-180' : ''}`}
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>

      {/* Dropdown panel */}
      {open && (
        <div className="absolute left-0 top-full mt-2 z-[300] flex w-full min-w-[220px] max-w-[min(100vw-2rem,42rem)] flex-col overflow-hidden rounded-xl border border-gray-100 bg-white shadow-xl animate-scale-in md:flex-row">
          {/* Parent categories (left column) */}
          <ul className="py-1 md:min-w-[220px] max-h-[18rem] overflow-y-auto">
            {categories.map((cat) => {
              const hasChildren = cat.children && cat.children.length > 0;
              const isParentSelected = cat.id === value;
              const isChildSelected = cat.children?.some((c) => c.id === value);
              return (
                <li
                  key={cat.id}
                  className={`flex items-center justify-between gap-2 px-3 py-2 cursor-pointer text-sm transition-colors ${
                    activeParentId === cat.id || isChildSelected
                      ? 'bg-red-50 text-red-700'
                      : isParentSelected
                      ? 'bg-red-100 text-red-800 font-semibold'
                      : 'text-gray-800 hover:bg-gray-50'
                  }`}
                  onMouseEnter={() => { if (hasChildren) setActiveParentId(cat.id); }}
                  onClick={() => {
                    if (hasChildren) {
                      setActiveParentId(cat.id);
                      return;
                    }
                    handleSelect(cat.id);
                  }}
                >
                  <span className="flex items-center gap-2">
                    {cat.icon && <span aria-hidden="true">{cat.icon}</span>}
                    {cat.name}
                  </span>
                  {hasChildren && (
                    <svg className="w-3.5 h-3.5 opacity-50 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  )}
                </li>
              );
            })}
          </ul>

          {/* Subcategories (right column) — shown when a parent with children is hovered */}
          {activeParent && activeParent.children && activeParent.children.length > 0 && (
            <ul className="py-1 md:min-w-[220px] max-h-[18rem] overflow-y-auto border-t border-gray-100 bg-gray-50 md:border-l md:border-t-0">
              {/* Option to select the parent category itself */}
              <li
                className={`px-3 py-2 cursor-pointer text-sm transition-colors font-medium ${
                  activeParent.id === value ? 'bg-red-100 text-red-800' : 'text-gray-600 hover:bg-white hover:text-gray-900'
                }`}
                onClick={() => handleSelect(activeParent.id)}
              >
                All in {activeParent.name}
              </li>
              <li className="border-t border-gray-200 my-0.5" />
              {activeParent.children.map((sub) => (
                <li
                  key={sub.id}
                  className={`px-3 py-2 cursor-pointer text-sm transition-colors ${
                    sub.id === value ? 'bg-red-100 text-red-800 font-semibold' : 'text-gray-700 hover:bg-white hover:text-red-700'
                  }`}
                  onClick={() => handleSelect(sub.id)}
                >
                  {sub.icon && <span className="mr-1.5" aria-hidden="true">{sub.icon}</span>}
                  {sub.name}
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
